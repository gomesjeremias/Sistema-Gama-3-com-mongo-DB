// db.js - Camada de abstração para MongoDB com Prisma

import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

// Dados iniciais para popular o sistema
const initialData = {
    users: [
        { username: 'admin', password: 'bibiaobia@06' }
    ],
    clientes: [
        { nome: 'João da Silva', email: 'joao.silva@email.com', telefone: '11987654321', status: 'Pago' },
        { nome: 'Maria Oliveira', email: 'maria.o@email.com', telefone: '21912345678', status: 'A pagar' },
        { nome: 'Carlos Pereira', email: 'carlos.p@email.com', telefone: '31955554444', status: 'Pago' },
    ],
    produtos: [
        { nome: 'Notebook Pro', codigo: 'NTK-001', descricao: 'Notebook de alta performance', preco: 7500.00, estoque: 15 },
        { nome: 'Mouse Sem Fio', codigo: 'MSE-002', descricao: 'Mouse ergonômico', preco: 150.00, estoque: 100 },
        { nome: 'Teclado Mecânico', codigo: 'TCD-003', descricao: 'Teclado para gamers', preco: 450.00, estoque: 50 },
    ],
    fornecedores: [
        { nome: 'Tech Distribuidora', cnpj: '11.222.333/0001-44', contato: 'contato@techdist.com', produtos: 'Notebooks, Mouses' },
        { nome: 'Periféricos Brasil', cnpj: '55.666.777/0001-88', contato: 'vendas@perifericosbr.com', produtos: 'Teclados, Monitores' },
    ]
};

/**
 * Inicializa o banco de dados com dados iniciais se estiver vazio
 */
export async function init() {
    try {
        // Verifica se já existem usuários
        const userCount = await prisma.user.count();
        
        if (userCount === 0) {
            console.log('Inicializando banco de dados com dados iniciais...');
            
            // Criar usuários
            for (const userData of initialData.users) {
                await prisma.user.create({
                    data: userData
                });
            }
            
            // Criar clientes
            const clientesCreated = [];
            for (const clienteData of initialData.clientes) {
                const cliente = await prisma.cliente.create({
                    data: clienteData
                });
                clientesCreated.push(cliente);
            }
            
            // Criar produtos
            const produtosCreated = [];
            for (const produtoData of initialData.produtos) {
                const produto = await prisma.produto.create({
                    data: produtoData
                });
                produtosCreated.push(produto);
            }
            
            // Criar fornecedores
            for (const fornecedorData of initialData.fornecedores) {
                await prisma.fornecedor.create({
                    data: fornecedorData
                });
            }
            
            // Criar vendas iniciais
            const vendasIniciais = [
                { 
                    clienteId: clientesCreated[0].id, 
                    produtoId: produtosCreated[0].id, 
                    quantidade: 1, 
                    valorTotal: 7500.00, 
                    formaPagamento: 'Cartão de Crédito', 
                    status: 'Pago',
                    data: new Date('2024-05-20')
                },
                { 
                    clienteId: clientesCreated[1].id, 
                    produtoId: produtosCreated[1].id, 
                    quantidade: 2, 
                    valorTotal: 300.00, 
                    formaPagamento: 'Boleto', 
                    status: 'A pagar',
                    data: new Date('2024-05-21')
                },
                { 
                    clienteId: clientesCreated[2].id, 
                    produtoId: produtosCreated[2].id, 
                    quantidade: 1, 
                    valorTotal: 450.00, 
                    formaPagamento: 'PIX', 
                    status: 'Pago',
                    data: new Date('2024-05-22')
                },
                { 
                    clienteId: clientesCreated[0].id, 
                    produtoId: produtosCreated[1].id, 
                    quantidade: 1, 
                    valorTotal: 150.00, 
                    formaPagamento: 'PIX', 
                    status: 'Pago',
                    data: new Date('2024-05-23')
                }
            ];
            
            for (const vendaData of vendasIniciais) {
                await prisma.venda.create({
                    data: vendaData
                });
            }
            
            console.log('Banco de dados inicializado com sucesso!');
        }
    } catch (error) {
        console.error('Erro ao inicializar banco de dados:', error);
    }
}

/**
 * Pega todos os itens de uma tabela
 * @param {string} tableName - Nome da tabela (ex: 'clientes')
 * @returns {Array}
 */
export async function getAll(tableName) {
    try {
        switch (tableName) {
            case 'users':
                return await prisma.user.findMany();
            case 'clientes':
                return await prisma.cliente.findMany();
            case 'produtos':
                return await prisma.produto.findMany();
            case 'fornecedores':
                return await prisma.fornecedor.findMany();
            case 'vendas':
                return await prisma.venda.findMany({
                    include: {
                        cliente: true,
                        produto: true
                    }
                });
            default:
                throw new Error(`Tabela '${tableName}' não encontrada`);
        }
    } catch (error) {
        console.error(`Erro ao buscar dados da tabela ${tableName}:`, error);
        return [];
    }
}

/**
 * Pega um item por ID de uma tabela
 * @param {string} tableName 
 * @param {string} id 
 * @returns {object | null}
 */
export async function getById(tableName, id) {
    try {
        switch (tableName) {
            case 'users':
                return await prisma.user.findUnique({ where: { id } });
            case 'clientes':
                return await prisma.cliente.findUnique({ where: { id } });
            case 'produtos':
                return await prisma.produto.findUnique({ where: { id } });
            case 'fornecedores':
                return await prisma.fornecedor.findUnique({ where: { id } });
            case 'vendas':
                return await prisma.venda.findUnique({ 
                    where: { id },
                    include: {
                        cliente: true,
                        produto: true
                    }
                });
            default:
                throw new Error(`Tabela '${tableName}' não encontrada`);
        }
    } catch (error) {
        console.error(`Erro ao buscar item ${id} da tabela ${tableName}:`, error);
        return null;
    }
}

/**
 * Salva (cria ou atualiza) um item em uma tabela
 * @param {string} tableName
 * @param {object} itemData - Dados do item. Se tiver 'id', atualiza. Senão, cria.
 */
export async function save(tableName, itemData) {
    try {
        const { id, ...data } = itemData;
        
        switch (tableName) {
            case 'users':
                if (id) {
                    return await prisma.user.update({
                        where: { id },
                        data
                    });
                } else {
                    return await prisma.user.create({ data });
                }
                
            case 'clientes':
                if (id) {
                    return await prisma.cliente.update({
                        where: { id },
                        data
                    });
                } else {
                    return await prisma.cliente.create({ data });
                }
                
            case 'produtos':
                if (id) {
                    return await prisma.produto.update({
                        where: { id },
                        data
                    });
                } else {
                    return await prisma.produto.create({ data });
                }
                
            case 'fornecedores':
                if (id) {
                    return await prisma.fornecedor.update({
                        where: { id },
                        data
                    });
                } else {
                    return await prisma.fornecedor.create({ data });
                }
                
            case 'vendas':
                // Para vendas, garantir que a data seja definida se não existir
                if (!data.data && !id) {
                    data.data = new Date();
                }
                
                if (id) {
                    return await prisma.venda.update({
                        where: { id },
                        data
                    });
                } else {
                    return await prisma.venda.create({ data });
                }
                
            default:
                throw new Error(`Tabela '${tableName}' não encontrada`);
        }
    } catch (error) {
        console.error(`Erro ao salvar item na tabela ${tableName}:`, error);
        throw error;
    }
}

/**
 * Remove um item de uma tabela pelo ID
 * @param {string} tableName 
 * @param {string} id 
 */
export async function remove(tableName, id) {
    try {
        switch (tableName) {
            case 'users':
                return await prisma.user.delete({ where: { id } });
            case 'clientes':
                return await prisma.cliente.delete({ where: { id } });
            case 'produtos':
                return await prisma.produto.delete({ where: { id } });
            case 'fornecedores':
                return await prisma.fornecedor.delete({ where: { id } });
            case 'vendas':
                return await prisma.venda.delete({ where: { id } });
            default:
                throw new Error(`Tabela '${tableName}' não encontrada`);
        }
    } catch (error) {
        console.error(`Erro ao remover item ${id} da tabela ${tableName}:`, error);
        throw error;
    }
}

/**
 * Limpa todos os registros de uma tabela. Ação perigosa.
 * @param {string} tableName
 */
export async function _dangerouslyClearTable(tableName) {
    try {
        switch (tableName) {
            case 'users':
                return await prisma.user.deleteMany();
            case 'clientes':
                return await prisma.cliente.deleteMany();
            case 'produtos':
                return await prisma.produto.deleteMany();
            case 'fornecedores':
                return await prisma.fornecedor.deleteMany();
            case 'vendas':
                return await prisma.venda.deleteMany();
            default:
                throw new Error(`Tabela '${tableName}' não encontrada`);
        }
    } catch (error) {
        console.error(`Erro ao limpar tabela ${tableName}:`, error);
        throw error;
    }
}

/**
 * Fecha a conexão com o banco de dados
 */
export async function disconnect() {
    await prisma.$disconnect();
}

// Exporta o cliente Prisma para uso direto se necessário
export { prisma };

