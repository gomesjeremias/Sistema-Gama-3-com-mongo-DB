// auth.js - Sistema de Autenticação com Prisma

import * as db from './db.js';

const SESSION_KEY = 'sales_app_session';

export async function login(username, password) {
    try {
        await db.init(); // Garante que os usuários existam
        const users = await db.getAll('users');
        const user = users.find(u => u.username === username && u.password === password);
        
        if (user) {
            // Simula a criação de um token/sessão
            localStorage.setItem(SESSION_KEY, JSON.stringify({ 
                loggedIn: true, 
                username: user.username, 
                timestamp: new Date().getTime() 
            }));
            return true;
        }
        return false;
    } catch (error) {
        console.error('Erro no login:', error);
        return false;
    }
}

export function logout() {
    localStorage.removeItem(SESSION_KEY);
}

export function checkAuth() {
    const session = localStorage.getItem(SESSION_KEY);
    if (!session) {
        return false;
    }
    // Opcional: poderia adicionar uma verificação de tempo de expiração da sessão aqui
    return JSON.parse(session).loggedIn;
}

export async function signup(username, password) {
    try {
        // Verifica se o usuário já existe
        const users = await db.getAll('users');
        const existingUser = users.find(u => u.username === username);
        
        if (existingUser) {
            console.log('Usuário já existe');
            return false;
        }
        
        // Cria novo usuário
        await db.save('users', { username, password });
        console.log(`Usuário ${username} criado com sucesso`);
        return true;
    } catch (error) {
        console.error('Erro no cadastro:', error);
        return false;
    }
}

